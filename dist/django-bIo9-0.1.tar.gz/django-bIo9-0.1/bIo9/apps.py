from django.apps import AppConfig


class Bio9Config(AppConfig):
    name = 'bIo9'
